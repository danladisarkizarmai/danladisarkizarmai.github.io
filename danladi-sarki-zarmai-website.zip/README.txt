DANLADI SARKI ZARMAI — PERSONAL WEBSITE

Files:
- index.html: the personal profile website
- assets/danladi-sarki-zarmai.jpg: portrait used on the website

HOW TO PUBLISH FOR FREE WITH GITHUB PAGES
1. Create or sign in to a GitHub account at https://github.com/
2. Create a new public repository. A suitable name is danladi-sarki-zarmai.
3. Upload index.html and the entire assets folder (keep the folder structure).
4. Open the repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. GitHub will provide a public website address after publishing.

GOOGLE INDEXING
1. Open https://search.google.com/search-console/
2. Add the published website as a URL-prefix property.
3. Verify ownership using one of the methods Google offers.
4. Use URL Inspection to request indexing for the homepage.
5. Indexing and appearance in search results are not guaranteed or immediate.

Before publishing:
- Confirm the spelling of the name and traditional title.
- Confirm the career dates, employer name, role, and qualifications.
- Add contact details only if the owner wants them public.
- This page intentionally does not include a phone number, email, or street address.
